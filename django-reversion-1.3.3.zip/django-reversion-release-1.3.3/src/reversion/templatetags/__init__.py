"""Template tags used by Reversion."""

